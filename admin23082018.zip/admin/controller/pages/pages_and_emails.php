<?php
class ControllerPagesAndEmails extends Controller {
	private $error = array();

	public function index() {
		
	}

}