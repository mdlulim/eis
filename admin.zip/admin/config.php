<?php
define('HTTP_SERVER', 'http://localhost/saleslogicmdu/admin/');
define('HTTP_CATALOG', 'http://localhost/saleslogicmdu/');

define('HTTPS_SERVER', 'http://localhost/saleslogicmdu/admin/');
define('HTTPS_CATALOG', 'http://localhost/saleslogicmdu/');

define('DIR_APPLICATION', '/Applications/XAMPP/htdocs/saleslogicmdu/admin/');
define('DIR_SYSTEM', '/Applications/XAMPP/htdocs/saleslogicmdu/system/');
define('DIR_IMAGE', '/Applications/XAMPP/htdocs/saleslogicmdu/image/');
define('DIR_LANGUAGE', '/Applications/XAMPP/htdocs/saleslogicmdu/admin/language/');
define('DIR_TEMPLATE', '/Applications/XAMPP/htdocs/saleslogicmdu/admin/view/template/');
define('DIR_CONFIG', '/Applications/XAMPP/htdocs/saleslogicmdu/system/config/');
define('DIR_CACHE', '/Applications/XAMPP/htdocs/saleslogicmdu/system/storage/cache/');
define('DIR_DOWNLOAD', '/Applications/XAMPP/htdocs/saleslogicmdu/system/storage/download/');
define('DIR_LOGS', '/Applications/XAMPP/htdocs/saleslogicmdu/system/storage/logs/');
define('DIR_MODIFICATION', '/Applications/XAMPP/htdocs/saleslogicmdu/system/storage/modification/');
define('DIR_UPLOAD', '/Applications/XAMPP/htdocs/saleslogicmdu/system/storage/upload/');
define('DIR_CATALOG', '/Applications/XAMPP/htdocs/saleslogicmdu/catalog/');
define('HELP_GUIDE','https://help.saleslogic.io/portal/home');

// define('DB_DRIVER', 'mysqli');
// define('DB_HOSTNAME', '52.232.82.221');
// define('DB_USERNAME', 'cloudlogicdev');
// define('DB_PASSWORD', 'P@$$w0rd()1234');
// define('DB_DATABASE', 'demo2');
// define('DB_PORT', '3306');
// define('DB_PREFIX', 'oc_');


define('DB_DRIVER',   'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'template_mdu');
define('DB_PORT',     '3306');
define('DB_PREFIX',   'oc_');
?>