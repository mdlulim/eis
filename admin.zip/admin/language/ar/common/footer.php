<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_footer'] = '<a href="http://www.opencart.com" target="_blank">OpenCart</a> &copy; 2009 - ' . date('Y') . ' جميع الحقوق محفوظة<br />ترجمة <a href="http://www.opencartarab.com" target="_blank">OpenCartArab</a>';
$_['text_version'] 	= 'الاصدار رقم %s';