<?php
class ControllerReportQuickReports extends Controller {
	public function index() {
		
	}
}